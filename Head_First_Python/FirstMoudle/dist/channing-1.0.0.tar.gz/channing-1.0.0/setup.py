from distutils.core import setup

setup(
	name			=	'channing',
	version			=	'1.0.0',
	py_modules		=	['channing'],
	author			=	'channing',
	author_email	=	'channig342@gmail.com'
)